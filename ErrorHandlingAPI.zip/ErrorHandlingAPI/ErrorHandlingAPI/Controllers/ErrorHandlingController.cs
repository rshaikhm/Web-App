﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ErrorHandlingAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ErrorHandlingController : ControllerBase
    {
               private readonly ILogger<ErrorHandlingController> _logger;
        private IConfiguration configuration;
        public ErrorHandlingController(ILogger<ErrorHandlingController> logger, IConfiguration iConfig)
        {
            _logger = logger;
            configuration = iConfig;
        }

        [HttpGet]
        public IActionResult Get()
        {
            string errDetails = "";
            try
            {
                string oradb = configuration.GetSection("ConnectionStrings").GetSection("OracleConstr").Value;

                //string oradb = "Data Source=(DESCRIPTION =" +
                //                "(ADDRESS = (PROTOCOL = TCP)(HOST = 10.0.25.155)(PORT = 1660))" +
                //                   "(CONNECT_DATA =" +
                //                     "(SERVER = DEDICATED)" +
                //                     "(SERVICE_NAME = RADB)));" +
                //                     "User Id=PCSREAD;Password=pcsread;";

                OracleConnection con = new OracleConnection(oradb);
                OracleCommand cmd = new OracleCommand();
                cmd.CommandText = "select m.PLANID, m.DERNAM, m.PAYENDDATE, e.*, d.SSNUM from DVCIMPORTMSTR m, DVCERROR e, DVCIMPORTDET d where m.PLANID = 'BCHA1234' and m.PAYENDDATE = '20-NOV-2020' and m.INDEXID = e.INDEXID and e.DVCRECORDID = d.DVCRECORDID order by m.PAYENDDATE desc";
                cmd.Connection = con;
                con.Open();
                OracleDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    Response.WriteAsync("Retrieving Value from DB.");
                    Response.WriteAsync("<table border='1'>");
                    Response.WriteAsync("<tr><th>PlanID</th><th>DERNAM</th><th>ERRORID</th></tr>");
                    while (dr.Read())
                    {
                        Response.WriteAsync("<tr>");
                        Response.WriteAsync("<td>" + dr["planId"].ToString() + "</td>");
                        Response.WriteAsync("<td>" + dr["dernam"].ToString() + "</td>");
                        Response.WriteAsync("<td>" + dr["errorid"].ToString() + "</td>");
                        Response.WriteAsync("</tr>");
                    }
                    Response.WriteAsync("</table>");
                }
                else
                {
                    Response.WriteAsync("No Data In DataBase");
                }
                con.Close();
                return Ok(dr);
            }
            catch (Exception ex)
            {
                errDetails = ex.Message;
            }
            return Ok(errDetails);
             
        }

    }
}
